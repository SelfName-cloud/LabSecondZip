﻿using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Лабораторная_работа_1
{
    public class BubbleSort
    {
        public int Count_operation = 0;
        // Поле, по-которому производится порядок сортировки строк.
        public readonly string All_alpha = @"АаБбВвГгДдЕеЁёЖжЗзИиЙйКкЛлМмНнОоПпРрСсТтУуФфХхЦцЧчШшЩщЪъЫыЬьЭэЮюЯя
                                    AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789!?,.()[]{}";

        //Метод, с помощью которого мы получаем номер первой буквы из поля All_alpha.
        public int Get_number_symbol(string str)
        {
            int index = 0;
            for(int i = 0; i <= All_alpha.Length; i++)
            {
                if (str[0] == All_alpha[i])
                {
                    index = i;
                    Count_operation++;
                    break;
                }
                
            }
            return index;
        }


        //Метод, который на основе полученной цифры из метода Get_number_alpha, сортирует массив строк.
        public string[] Bubble_sort(string[] array) 
        { 
            
            for(int k = 0; k < array.Length; k++)
            {
                array[k] = array[k].Trim();
                Count_operation++;
            }

            string temp;
            for(int i = 0; i < array.Length; i++)
            {
                for(int j = i + 1; j < array.Length; j++)
                {
                    if (Get_number_symbol(array[i]) > Get_number_symbol(array[j])) 
                    {
                        temp = array[i];
                        array[i] = array[j];
                        array[j] = temp;
                        Count_operation++;
                    }

                }
            }
                
            return array;
        }


        static void Main()
        {
            var bs = new BubbleSort();
            var list = new List<string>();
            XmlDocument xDoc = new XmlDocument();
            string XMLPath = Directory.GetCurrentDirectory() + @"\XMLFile1.xml";
            xDoc.Load(XMLPath);

            XmlNodeList Alist = xDoc.GetElementsByTagName("array");
            XmlNodeList Clist = xDoc.GetElementsByTagName("item");

            for(int j = 0; j < Alist.Count; j++)
            {
                Alist[j].InnerText.ToString();
            }
            
            
            Console.WriteLine("Введите количество слов:");
            var count = int.Parse(Console.ReadLine());
            
            int i = 0;
            while(i < count)
            {
                Console.WriteLine("Введите "  + (i+1).ToString() + " слово:");
                string word = Console.ReadLine();
                list.Add(word);
                i++;
            }
            Console.WriteLine("Отсортированный список:");
            foreach(var j in bs.Bubble_sort(list.ToArray()))
            {
                Console.WriteLine(j);
            }
            Console.WriteLine("Количество операций:" + bs.Count_operation.ToString());
            Console.ReadKey();

            

            
            
            
          
        }
            
            
            
     }

}

